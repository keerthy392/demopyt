from django.http import HttpResponse
from django.shortcuts import render
from .models import Place
from .models import Person

# Create your views here.
def demo(request):
    obj1=Place.objects.all()
    obj2=Person.objects.all()




    return render(request,'index.html',{'result':obj1,'person':obj2})
